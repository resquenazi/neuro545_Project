extern void write_xplot_sarray_sampling();
extern void write_xplot_sarray_sampling_color();
extern void write_xplot_sarray();
extern void append_xplot_spike_sampling();
extern void append_xplot_sarray_sampling();
extern void append_xplot_sarray_sampling_color();
extern void append_xplot_sarray();
extern void append_xplot_farray_histogram();
extern void append_xplot_farray_dx();
extern void append_xplot_farray_dx_int();
extern void append_xplot_const_plot();

extern void append_xplot_auto_hist_pair();

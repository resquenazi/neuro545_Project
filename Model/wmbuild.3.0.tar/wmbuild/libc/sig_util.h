extern void mean_autocorr_noise();
extern void mean_crosscorr_noise();
extern float *gaussian_white_noise();
extern float *gaussian_white_noise_pseed();
extern float *gaussian_corr_noise();
extern float *gaussian_corr_noise_pseed();
extern float *leaky_integrate();


// float mod_wav_util_ran2();
// void mod_wav_make_conn_list_rad();
// void mod_wav_debug_write_conn_image();

extern void mod_wav_fbars_prep();
extern void mod_wav_fbars_done();
extern void mod_wav_fbars_get_response();
extern void mod_wav_run_fbars();

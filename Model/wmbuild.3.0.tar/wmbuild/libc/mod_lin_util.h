/***  MOD_LIN_UTIL.H  ***/

extern void mod_lin_run_lin_01();

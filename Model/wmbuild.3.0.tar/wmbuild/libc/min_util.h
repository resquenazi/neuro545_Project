extern void minu_test_funcd();
extern float minu_test_func();
extern void minu_pr();
extern void minu_test_fit();

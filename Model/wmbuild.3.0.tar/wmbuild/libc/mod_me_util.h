// extern float mod_me_util_bar_resp();
// extern  void mod_me_util_bar_sim();
// extern  void mod_me_get_quad_opp_k();
extern void mod_me_get_quad_opp_filters();

// extern struct mod_me_fstruct **mod_me_fs_create();
// extern   void mod_me_fs_top_create();
// extern   void mod_me_fs_free_r();
// extern   void mod_me_fs_free();
// extern   void mod_me_fs_flag_eye();
// extern    int mod_me_fs_get_fi();
// extern   void mod_me_fs_build_list()

// extern   void mod_me_get_filt_work();
// extern   void mod_me_prep_basic();
// extern   void mod_me_filt_template();

// extern struct mod_me_fstruct **mod_me_get_quad_opp_filters_o();
// extern   void mod_me_get_norm_filters();
// extern   void mod_me_normalize_filter();
// extern   void mod_me_normalize_filters();
// extern   void mod_me_filters_free()

// extern   void mod_me_binoc_set_thresh();
// extern   void model_me_01_prep_o();
// extern   void model_me_01_prep();

// extern struct mod_me_noise *mod_me_noise_init();

// extern   void mod_me_noise_add();
// extern struct mod_me_v1resp *model_me_v5_resp_init();

extern void mod_me_normalize_quad_opp_filters();
extern void model_me_01_prep_ft();
extern void model_me_01_done();
extern void mod_me_compute_response_quad_opp_from_ft();
extern void model_me_01_get_response();


//
//  ME_V5
//

// void   mod_me_v5_pop_conn()
// void   model_me_v5_pop_prep()
// void   model_me_v5_prep()
// void   mod_me_v5_handover()
// void   mod_me_v5_v1surr_sum()

// void   mod_me_v5_raw_resp();
// void   mod_me_v5_raw_top();
// void   mod_me_v5_norm_v1_work();
// void   mod_me_v5_norm_v1_disp();
// void   mod_me_v5_norm_v1();
// void   mod_me_v5_opp_v1_work();
// void   mod_me_v5_opp_v1()
// void   mod_me_v5_binoc_v1_work();
// void   mod_me_v5_binoc_v1();
// float *mod_me_v5_mt_nl();
// void   mod_me_v5_mt_work();
// void   mod_me_v5_mt();
// void   mod_me_v5_pop();
// void   mod_me_v5_mix_worker();
// void   mod_me_v5_mix_v1();
// void   model_me_v5_get_response();


extern void mod_me_run_me_gabor_01();
extern void mod_me_run_me_v5();
extern void mod_me_run_filter_xyt();
extern void mod_me_run_gabor_comp();
extern void mod_me_run_ds_simp_01();
extern void mod_me_run_ds_liv3();
extern void mod_me_run_mem();
extern void mod_me_run_reich();

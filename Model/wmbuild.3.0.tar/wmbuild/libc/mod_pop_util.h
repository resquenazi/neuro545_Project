
// Called by wm.c and mm.c
extern void mod_pop_run();
